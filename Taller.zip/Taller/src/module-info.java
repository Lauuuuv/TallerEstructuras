/**
 * 
 */
/**
 * @author david
 *
 */
module Taller {
	requires java.desktop;
}