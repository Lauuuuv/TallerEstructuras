package co.edu.unbosque.controller;

import co.edu.unbosque.model.Ciclos;
import co.edu.unbosque.model.EstructuraDeSeleccion;
import co.edu.unbosque.view.View;

public class Controller {
	Ciclos c;
	EstructuraDeSeleccion e;
	View v;

	public Controller() {
		c = new Ciclos();
		e = new EstructuraDeSeleccion();
		v = new View();
		funcionar();
	}

	public void funcionar() {
		while (v.getMenu()!=0) {
			int nMenu = v.showMenu();
			v.setMenu(nMenu);
			switch(v.getMenu()) {
			case 1:
				System.out.println(e.ejercicio8(v.leerNumero("Ingresa el n�mero de dos digitos")));
				break;
			case 2:
				System.out.println(e.ejercicio18(v.leerNumero("INgresa un n�mero de 3 digitos")));
				break;
			case 3:
				System.out.println(e.ejercicio28(v.leerNumero("Ingresa un n�mero menor o igual que 50")));
				break;
			case 4:
				System.out.println(e.ejercicio38(v.leerNumero("Ingresa el primer n�mero"), v.leerNumero("Ingresa el segundo n�mero"), v.leerNumero("Ingresa el tercer n�mero")));
				break;
			case 5:
				System.out.println(e.ejercicio48(v.leerNumero("INgresa un n�mero mayor a 100")));
			case 6: 
				System.out.println("Los n�mero pares entre 20 y 200 son: \n"+c.ejercicio8());
				break;
			case 7:
				System.out.println(c.ejercicio18(v.leerNumero("Ingrese el primer n�mero"), v.leerNumero("Ingrese el segundo n�mero")));
				break;
			case 8:
				System.out.println(c.ejercicio28(v.leerNumero("Ingresa el primer n�mero"), v.leerNumero("Ingresa el segundo n�mero")));
				break;
			case 9:
				System.out.println(c.ejercicio38(v.leerNumero("Ingrese el n�mero")));
				break;
			case 10:
				break;
			case 11:
				System.out.println("Adi�s.");
				break;
			default: 
				System.out.println("Ingrese un n�mero correcto");
			}
		}

	}
}
