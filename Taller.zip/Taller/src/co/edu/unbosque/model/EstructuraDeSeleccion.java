package co.edu.unbosque.model;

public class EstructuraDeSeleccion {
	
	public String ejercicio8(int no1) {
		String respuesta = "No son ambos n�meros primos.";
		char[] digitosno1 = String.valueOf(no1).toCharArray();
		if(digitosno1[0]=='2'||digitosno1[0]=='3'||digitosno1[0]=='5'||digitosno1[0]=='7') {
			if (digitosno1[1]=='2'||digitosno1[1]=='3'||digitosno1[1]=='5'||digitosno1[1]=='7') {
				respuesta = "Si son ambos n�meros primos.";
			}
		}
		return respuesta;
	}
	
	public String ejercicio18(int no1) {
		char[] digitosno1 = String.valueOf(no1).toCharArray();
		String respuesta = "No hay multiplos entre si";
		if(Integer.parseInt(String.valueOf(digitosno1[2]))%Integer.parseInt(String.valueOf(digitosno1[0]))==0||Integer.parseInt(String.valueOf(digitosno1[1]))%Integer.parseInt(String.valueOf(digitosno1[0]))==0) {
			respuesta="Si hay multiplos entre si";
		}
		else if (Integer.parseInt(String.valueOf(digitosno1[2]))%Integer.parseInt(String.valueOf(digitosno1[1]))==0||Integer.parseInt(String.valueOf(digitosno1[0]))%Integer.parseInt(String.valueOf(digitosno1[1]))==0) {
			respuesta="Si hay multiplos entre si";
		}
		else if (Integer.parseInt(String.valueOf(digitosno1[1]))%Integer.parseInt(String.valueOf(digitosno1[2]))==0||Integer.parseInt(String.valueOf(digitosno1[1]))%Integer.parseInt(String.valueOf(digitosno1[2]))==0) {
			respuesta="Si hay multiplos entre si";
		}
		return respuesta;
	}
	
	public String ejercicio28(int no1) {
		String respuesta="No es un numero primo";
		if(no1>50) {
			respuesta= "No es un n�mero menor que 50";
		}
		else {
			if(no1==2||no1==3||no1==5||no1==7||no1==11||no1==13||no1==17||no1==19||no1==23||no1==29||no1==31||no1==37||no1==41||no1==43||no1==47) {
				respuesta = "Si es un numero primo";
			}			
		}
		return respuesta;
	}
	
	public String ejercicio38(int no1, int no2, int no3) {
		char [] arreglo1 = String.valueOf(no1).toCharArray();
		char [] arreglo2 = String.valueOf(no2).toCharArray();
		char [] arreglo3 = String.valueOf(no3).toCharArray();
		String respuesta = "No son igules los ultimos 3 digitos.";
		if (arreglo1[arreglo1.length-1]==arreglo2[arreglo2.length-1]&&arreglo2[arreglo2.length-1]==arreglo3[arreglo3.length-1]) {
			respuesta = "Son iguales las 3 posiciones finales";
		}
		return respuesta;
	}
	
	
	public String ejercicio48(int no1) {
		String respuesta="No es un numero primo";
		if(no1>100) {
			respuesta= "No es un n�mero menor que 100";
		}
		else {
			if(no1==2||no1==3||no1==5||no1==7||no1==11||no1==13||no1==17||no1==19||no1==23||no1==29||no1==31||no1==37||no1==41||no1==43||no1==47||
					no1==53||no1==59||no1==61||no1==67||no1==71||no1==73||no1==79||no1==83||no1==89||no1==97) {
				respuesta = "Si es un numero primo";
			}			
		}
		return respuesta;
	}
}
