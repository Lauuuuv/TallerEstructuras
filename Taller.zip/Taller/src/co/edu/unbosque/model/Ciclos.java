package co.edu.unbosque.model;


public class Ciclos {
	
	public String ejercicio8() {
		String respuesta = "";
		for (int i = 20; i <= 200; i++) {
			if (i % 2 == 0) {
				respuesta+=i+"\n";
			}
		}
		return respuesta;
	}
	
	public String ejercicio18(int no1, int no2) {
		int mayor;
		int menor;
		String mensaje = "";
		if (no1>no2) {
			mayor = no1;
			menor = no2;
		}
		else {
			mayor = no2;
			menor = no1;
		}
		for (int i = menor; i <= mayor; i++) {
			if (i%5==0) {
				mensaje += i+"\n";
			}
		}
		return mensaje;
	}
	
	public String ejercicio28(int no1, int no2 ) {
		int contador1 = 0;
		int contador2 = 0;
		String respuesta = ""; 
		char[] arreglo1 = String.valueOf(no1).toCharArray(); 
		char[] arreglo2 = String.valueOf(no2).toCharArray(); 
		for (int i = 0; i < arreglo1.length; i++) {
			if (Integer.parseInt(String.valueOf(arreglo1[i]))==2||Integer.parseInt(String.valueOf(arreglo1[i]))==3||Integer.parseInt(String.valueOf(arreglo1[i]))==5||
					Integer.parseInt(String.valueOf(arreglo1[i]))==7) {
				contador1++;
			}
		}
		System.out.println(contador1);
		for (int i = 0; i < arreglo2.length; i++) {
			if (Integer.parseInt(String.valueOf(arreglo2[i]))==2||Integer.parseInt(String.valueOf(arreglo2[i]))==3||Integer.parseInt(String.valueOf(arreglo2[i]))==5||
					Integer.parseInt(String.valueOf(arreglo2[i]))==7) {
				contador2++;
			}
		}
		System.out.println(contador2);
		if (contador1 == contador2) {
			respuesta = "Tienen igual n�mero de primos";
		}
		else if (contador2>contador1) {
			respuesta = "El n�mero dos tiene m�s primos";
		}
		else {
			respuesta = "El n�mero uno tiene m�s primos";
		}
		return respuesta;
	}
	
	public String ejercicio38(int numero) {
		String respuesta = "";
		for (int i = 1; i <= 10; i++) {
			respuesta += numero+"x"+i+"="+numero*i+"\n";  
		}
		return respuesta;
	}
	
	

}
