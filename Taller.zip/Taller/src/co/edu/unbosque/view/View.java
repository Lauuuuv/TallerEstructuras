package co.edu.unbosque.view;
import javax.swing.JOptionPane;

public class View {

	int menu = -1;

	public View () {
	}

	public int leerNumero(String mensaje) {
		int dato =0;
		String respuesta= JOptionPane.showInputDialog(mensaje);
		dato = Integer.parseInt(respuesta);					
		return dato;
	}
	
	public int showMenu() {
		
		int respuesta = 0;
		boolean condicion = false;
		do {
			String mensaje=JOptionPane.showInputDialog("Ingrese lo que quiere hacer:"
					+"\n 1. Ejercicio 8 (estructura de selecci�n)."
					+"\n 2. Ejercicio 18 (estructura de selecci�n)."
					+"\n 3.	Ejercicio 28 (estructura de selecci�n)."
					+"\n 4. Ejercicio 38 (estructura de selecci�n)."
					+"\n 5. Ejercicio 48 (estructura de selecci�n) "
					+"\n 6. Ejercicio 8 (ciclos)."
					+"\n 7. Ejercicio 18 (ciclos)."
					+"\n 8.	Ejercicio 28 (ciclos)."
					+"\n 9. Ejercicio 38 (ciclos)."
					+"\n 10. Ejercicio 48 (ciclos) "
					+"\n 11. Salir.");
			try {
			respuesta=Integer.parseInt(mensaje);
			condicion=true;
			}
			catch (Exception e) {
			}
		} while (condicion == false);
			return respuesta;

	}

	public int getMenu() {
		return menu;
	}

	public void setMenu(int menu) {
		this.menu = menu;
	}
}